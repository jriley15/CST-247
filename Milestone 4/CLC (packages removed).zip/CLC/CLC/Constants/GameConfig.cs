﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CLC.Constants
{
    public class GameConfig
    {
        /** Game Config variables **/

        public static readonly int WIDTH = 10;
        public static readonly int HEIGHT = 10;
        public static readonly int BOMB_CHANCE = 10;


    }
}